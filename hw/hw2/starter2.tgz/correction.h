/**
 */
#include <stdbool.h>

/** Maximum length of a word in the correction list. */
#define WORD_LIMIT 20
