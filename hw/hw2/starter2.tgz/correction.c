/**
 */

#include "correction.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/** Maximum number of words on the correction list. */
#define CORRECTION_LIMIT 50000

/** Exit status for a bad correction list. */
#define INVALID_CLIST_STATUS 100
